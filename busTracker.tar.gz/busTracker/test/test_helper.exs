ExUnit.start()

Ecto.Adapters.SQL.Sandbox.mode(BusTracker.Repo, :manual)

