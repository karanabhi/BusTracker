defmodule BusTrackerWeb.PageViewTest do
  use BusTrackerWeb.ConnCase, async: true
end
