defmodule BusTrackerWeb.LayoutView do
  use BusTrackerWeb, :view
end
